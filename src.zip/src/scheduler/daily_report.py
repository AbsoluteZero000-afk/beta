"""
daily_report.py
Sends EOD Slack summary.
"""
from __future__ import annotations

import logging
import os
from datetime import date
from pathlib import Path

import requests
from dotenv import load_dotenv

load_dotenv(dotenv_path=Path(__file__).resolve().parents[2] / ".env")
logger        = logging.getLogger(__name__)
SLACK_WEBHOOK = os.environ.get("SLACK_WEBHOOK_URL", "")


def format_report(eod_summary: dict, account_info: dict) -> str:
    today       = date.today().strftime("%b %d, %Y")
    equity      = float(account_info.get("equity", 0))
    cash        = float(account_info.get("cash", 0))
    day_pnl     = float(account_info.get("equity", 0)) - float(account_info.get("last_equity", 0))
    day_pnl_pct = (day_pnl / max(float(account_info.get("last_equity", 1)), 1)) * 100

    def fmt(trades):
        if not trades: return "  _none_"
        return "\n".join(
            f"  {'✅' if t['pnl_pct'] > 0 else '❌'} {t['symbol']:8s} {t['pnl_pct']:+.1f}%"
            for t in trades
        )

    lines = [
        f"*QuantEdge Daily Report — {today}*",
        f"💰 *Equity:* ${equity:,.0f}   📈 *Day P&L:* ${day_pnl:+,.0f} ({day_pnl_pct:+.2f}%)   💵 *Cash:* ${cash:,.0f}",
        f"",
        f"*Shares Closed ({len(eod_summary.get('closed_shares',[]))})* \n{fmt(eod_summary.get('closed_shares',[]))}",
        f"*Options Closed ({len(eod_summary.get('closed_options',[]))})* \n{fmt(eod_summary.get('closed_options',[]))}",
    ]
    if eod_summary.get("held_options"):
        lines.append(f"*Options Held Overnight ({len(eod_summary['held_options'])})* \n{fmt(eod_summary['held_options'])}")
    if eod_summary.get("unexpected"):
        lines.append(f"⚠️ *UNEXPECTED POSITIONS:* {eod_summary['unexpected']}")
    return "\n".join(lines)


def send_slack(message: str) -> bool:
    if not SLACK_WEBHOOK:
        print(message)
        return False
    try:
        r = requests.post(SLACK_WEBHOOK, json={"text": message}, timeout=10)
        r.raise_for_status()
        return True
    except Exception as e:
        logger.error(f"Slack failed: {e}")
        print(message)
        return False


def run_daily_report(eod_summary: dict, account_info: dict) -> None:
    send_slack(format_report(eod_summary, account_info))


if __name__ == "__main__":
    dummy_eod = {
        "date": str(date.today()),
        "closed_shares":  [{"symbol": "NVDA", "pnl_pct": 2.3}, {"symbol": "TSLA", "pnl_pct": -1.1}],
        "closed_options": [{"symbol": "SOFI250314C00015000", "pnl_pct": 87.5}],
        "held_options":   [{"symbol": "UPST250314C00085000", "pnl_pct": 42.0, "days_held": 1}],
        "unexpected":     [],
    }
    dummy_account = {"equity": 115420.50, "last_equity": 113200.00, "cash": 45200.00}
    run_daily_report(dummy_eod, dummy_account)
