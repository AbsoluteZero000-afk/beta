"""
live_runner.py — Phase 9
Hybrid gap-and-go: shares (normal conviction) + options (high conviction).
Run at 9:30 AM ET every trading day.

Usage:
    python -m src.scheduler.live_runner          # paper
    python -m src.scheduler.live_runner --live   # live (careful!)
"""
from __future__ import annotations

import argparse
import logging
import os
import time
from datetime import date, timedelta
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.client import TradingClient
from alpaca.trading.requests import MarketOrderRequest
from alpaca.trading.enums import OrderSide, TimeInForce

from src.strategies.signal_router import route_signal
from src.strategies.options_executor import execute_options_trade
from src.scheduler.state_manager import (
    load_state, save_state, add_position, add_order,
    needs_eod_cleanup, reconcile_with_alpaca, Position,
)
from src.scheduler.eod_reconciler import run_eod_reconcile

load_dotenv(dotenv_path=Path(__file__).resolve().parents[2] / ".env")
logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)-8s  %(message)s")
logger = logging.getLogger(__name__)

MIN_PRICE      = 5.0
MIN_AVG_VOLUME = 500_000
ATR_PERIOD     = 14
ATR_STOP_MULT  = 1.0
MAX_POSITIONS  = 5
SCAN_LOOKBACK  = 30

try:
    from tests.backtest_gap_and_go import SP500
except ImportError:
    SP500 = ["AAPL","MSFT","NVDA","TSLA","AMZN","META","GOOGL","AMD","SOFI","UPST",
             "PLTR","COIN","HOOD","RIVN","RBLX","DASH","AFRM","LYFT","SNAP","MSTR"]


def scan_gaps(data_client) -> list[dict]:
    today = date.today()
    start = today - timedelta(days=SCAN_LOOKBACK)
    logger.info(f"Scanning {len(SP500)} symbols for gaps on {today}...")
    candidates = []

    for i in range(0, len(SP500), 50):
        batch = SP500[i:i+50]
        try:
            req    = StockBarsRequest(symbol_or_symbols=batch, timeframe=TimeFrame.Day,
                                      start=str(start), end=str(today), adjustment="all")
            df_all = data_client.get_stock_bars(req).df
        except Exception as e:
            logger.warning(f"Batch failed: {e}")
            continue

        for sym in batch:
            try:
                df = df_all.xs(sym, level="symbol").copy()
                df.index = pd.to_datetime(df.index).tz_convert(None)
            except KeyError:
                continue
            if len(df) < ATR_PERIOD + 2: continue

            today_row = df[df.index.date == today]
            if today_row.empty: continue

            idx        = df.index.get_loc(today_row.index[0])
            prev_close = float(df.iloc[idx-1]["close"])
            open_price = float(today_row.iloc[0]["open"])
            gap_pct    = (open_price - prev_close) / prev_close * 100
            if open_price < MIN_PRICE: continue

            hist      = df.iloc[max(0, idx-20):idx]
            avg_vol   = float(hist["volume"].mean())
            if avg_vol < MIN_AVG_VOLUME: continue
            vol_ratio = float(today_row.iloc[0]["volume"]) / avg_vol

            high, low, cp = df["high"], df["low"], df["close"].shift(1)
            tr  = pd.concat([(high-low),(high-cp).abs(),(low-cp).abs()], axis=1).max(axis=1)
            atr = float(tr.iloc[-ATR_PERIOD:].mean())

            decision = route_signal(sym, gap_pct, vol_ratio,
                                    available_capital=20_000, options_enabled=True)
            if not decision: continue

            stop = (open_price - ATR_STOP_MULT * atr if decision.direction == "long"
                    else open_price + ATR_STOP_MULT * atr)

            candidates.append({
                "symbol": sym, "gap_pct": round(gap_pct, 2),
                "vol_ratio": round(vol_ratio, 2), "open": open_price,
                "atr": round(atr, 4), "stop": round(stop, 4),
                "direction": decision.direction, "conviction": decision.conviction,
                "route": decision.route, "option_type": decision.option_type,
                "trade_capital": decision.trade_capital,
                "score": abs(gap_pct) * min(vol_ratio, 3) * (1.5 if decision.conviction=="high" else 1.0),
            })

    candidates.sort(key=lambda x: x["score"], reverse=True)
    logger.info(f"Found {len(candidates)} setups → taking top {MAX_POSITIONS}")
    return candidates[:MAX_POSITIONS]


def execute_trade(trading_client, data_client, c, state, paper):
    sym = c["symbol"]
    if c["route"] == "options":
        logger.info(f"  OPTIONS: {sym} {c['option_type'].upper()} gap={c['gap_pct']:+.1f}%")
        order = execute_options_trade(
            client=trading_client, symbol=sym, option_type=c["option_type"],
            current_price=c["open"], max_premium=c["trade_capital"], paper=paper,
        )
        trade_type = "options"
    else:
        qty        = max(1, int(c["trade_capital"] / c["open"]))
        order_side = OrderSide.BUY if c["direction"] == "long" else OrderSide.SELL
        logger.info(f"  SHARES:  {sym} {c['direction'].upper()} {qty}sh gap={c['gap_pct']:+.1f}%")
        try:
            order = trading_client.submit_order(MarketOrderRequest(
                symbol=sym, qty=qty, side=order_side,
                time_in_force=TimeInForce.DAY,
            ))
        except Exception as e:
            logger.error(f"  {sym} share order failed: {e}")
            order = None
        trade_type = "shares"

    if order:
        pos = Position(
            symbol=sym, entry_price=c["open"],
            qty=c["trade_capital"] // c["open"],
            stop=c["stop"], direction=c["direction"],
            trade_type=trade_type,
            contract=getattr(order, "symbol", None) if trade_type == "options" else None,
            entry_date=str(date.today()), conviction=c["conviction"],
            gap_pct=c["gap_pct"], vol_ratio=c["vol_ratio"],
        )
        add_position(state, pos)
        add_order(state, str(order.id))


def run(paper=True):
    trading_client = TradingClient(os.environ["ALPACA_API_KEY"],
                                   os.environ["ALPACA_SECRET_KEY"], paper=paper)
    data_client    = StockHistoricalDataClient(os.environ["ALPACA_API_KEY"],
                                               os.environ["ALPACA_SECRET_KEY"])
    state = load_state()

    if needs_eod_cleanup(state):
        logger.warning("Missed EOD — running emergency reconcile...")
        run_eod_reconcile(paper=paper)

    state = reconcile_with_alpaca(state, trading_client.get_all_positions())

    candidates = scan_gaps(data_client)
    if not candidates:
        logger.info("No gap setups today.")
        return

    acct = trading_client.get_account()
    logger.info(f"Equity: ${float(acct.equity):,.0f} | Buying power: ${float(acct.buying_power):,.0f}")

    for c in candidates:
        execute_trade(trading_client, data_client, c, state, paper)
        time.sleep(0.5)

    logger.info(f"Done — {len(candidates)} trades placed.")
    save_state(state)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--live", action="store_true")
    args = parser.parse_args()
    run(paper=not args.live)
