"""
eod_reconciler.py
Runs at 3:55 PM ET every trading day.
Closes ALL share positions. Closes losing options. Holds winning options up to 3 days.
"""
from __future__ import annotations

import logging
import os
from datetime import date, timedelta
from pathlib import Path

from dotenv import load_dotenv
from alpaca.trading.client import TradingClient

load_dotenv(dotenv_path=Path(__file__).resolve().parents[2] / ".env")
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)-8s  %(message)s")

MAX_OPTION_HOLD_DAYS = 3
WINNER_THRESHOLD     = 0.10


def run_eod_reconcile(paper: bool = True) -> dict:
    client = TradingClient(os.environ["ALPACA_API_KEY"],
                           os.environ["ALPACA_SECRET_KEY"], paper=paper)
    try:
        client.cancel_orders()
        logger.info("Cancelled all open orders.")
    except Exception as e:
        logger.warning(f"Cancel orders failed: {e}")

    positions      = client.get_all_positions()
    closed_shares  = []
    closed_options = []
    held_options   = []

    for pos in positions:
        symbol   = pos.symbol
        pnl_pct  = float(pos.unrealized_plpc or 0)
        is_option = (str(getattr(pos, "asset_class", "")) == "us_option"
                     or len(symbol) > 10)

        if not is_option:
            try:
                client.close_position(symbol)
                closed_shares.append({"symbol": symbol, "pnl_pct": round(pnl_pct*100, 2)})
                logger.info(f"  Closed shares: {symbol} pnl={pnl_pct*100:+.1f}%")
            except Exception as e:
                logger.error(f"  Failed to close {symbol}: {e}")
        else:
            entry_date = getattr(pos, "created_at", None)
            days_held  = 0
            if entry_date:
                try:
                    days_held = (date.today() - entry_date.date()).days
                except Exception:
                    pass

            if pnl_pct > WINNER_THRESHOLD and days_held < MAX_OPTION_HOLD_DAYS:
                held_options.append({"symbol": symbol, "pnl_pct": round(pnl_pct*100, 2), "days_held": days_held})
                logger.info(f"  Holding option: {symbol} pnl={pnl_pct*100:+.1f}% day {days_held+1}/3")
            else:
                try:
                    client.close_position(symbol)
                    closed_options.append({"symbol": symbol, "pnl_pct": round(pnl_pct*100, 2)})
                    logger.info(f"  Closed option: {symbol} pnl={pnl_pct*100:+.1f}%")
                except Exception as e:
                    logger.error(f"  Failed to close option {symbol}: {e}")

    remaining  = client.get_all_positions()
    unexpected = [p.symbol for p in remaining
                  if p.symbol not in [h["symbol"] for h in held_options]]
    if unexpected:
        logger.critical(f"UNEXPECTED OPEN POSITIONS: {unexpected}")

    summary = {
        "date": str(date.today()),
        "closed_shares": closed_shares,
        "closed_options": closed_options,
        "held_options": held_options,
        "unexpected": unexpected,
    }
    logger.info(f"EOD complete: {len(closed_shares)} shares, "
                f"{len(closed_options)} options closed, {len(held_options)} held.")
    return summary


if __name__ == "__main__":
    import argparse, json
    parser = argparse.ArgumentParser()
    parser.add_argument("--live", action="store_true")
    args = parser.parse_args()
    print(json.dumps(run_eod_reconcile(paper=not args.live), indent=2))
