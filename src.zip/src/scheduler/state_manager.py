"""
state_manager.py
Tracks all open positions and orders in state.json.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, asdict
from datetime import date, datetime
from pathlib import Path
from typing import Literal

logger    = logging.getLogger(__name__)
STATE_FILE = Path(__file__).resolve().parent / "state.json"


@dataclass
class Position:
    symbol:      str
    entry_price: float
    qty:         float
    stop:        float
    direction:   str
    trade_type:  Literal["shares", "options"]
    contract:    str | None
    entry_date:  str
    conviction:  str
    gap_pct:     float
    vol_ratio:   float


@dataclass
class State:
    date:          str
    positions:     dict
    orders_placed: list
    eod_closed:    bool
    last_updated:  str


def _empty_state() -> State:
    return State(date=str(date.today()), positions={},
                 orders_placed=[], eod_closed=False,
                 last_updated=datetime.now().isoformat())


def load_state() -> State:
    if not STATE_FILE.exists():
        return _empty_state()
    try:
        with open(STATE_FILE) as f:
            return State(**json.load(f))
    except Exception as e:
        logger.warning(f"State load failed: {e}")
        return _empty_state()


def save_state(state: State) -> None:
    state.last_updated = datetime.now().isoformat()
    with open(STATE_FILE, "w") as f:
        json.dump(asdict(state), f, indent=2, default=str)


def add_position(state: State, pos: Position) -> State:
    state.positions[pos.symbol] = asdict(pos)
    save_state(state)
    return state


def remove_position(state: State, symbol: str) -> State:
    state.positions.pop(symbol, None)
    save_state(state)
    return state


def add_order(state: State, order_id: str) -> State:
    state.orders_placed.append(order_id)
    save_state(state)
    return state


def mark_eod_closed(state: State) -> State:
    state.eod_closed = True
    save_state(state)
    return state


def needs_eod_cleanup(state: State) -> bool:
    return state.date != str(date.today()) and not state.eod_closed


def reconcile_with_alpaca(state: State, alpaca_positions: list) -> State:
    alpaca_symbols = {p.symbol for p in alpaca_positions}
    stale = [s for s in state.positions if s not in alpaca_symbols]
    for sym in stale:
        logger.warning(f"Removing stale position: {sym}")
        state.positions.pop(sym)
    save_state(state)
    return state
