"""Database layer — PostgreSQL + TimescaleDB."""
