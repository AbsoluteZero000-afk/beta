"""
options_executor.py
Finds the best options contract and places the order via Alpaca.
"""
from __future__ import annotations

import logging
from datetime import date, timedelta

from alpaca.trading.client import TradingClient
from alpaca.trading.requests import GetOptionContractsRequest, MarketOrderRequest
from alpaca.trading.enums import OrderSide, TimeInForce, ContractType

logger = logging.getLogger(__name__)

TARGET_DELTA_MIN  = 0.35
TARGET_DELTA_MAX  = 0.55
MIN_OPEN_INTEREST = 100
MIN_VOLUME        = 10


def find_best_contract(client, symbol, option_type, current_price, max_dte=7):
    today         = date.today()
    exp_limit     = today + timedelta(days=max_dte)
    contract_type = ContractType.CALL if option_type == "call" else ContractType.PUT
    strike_min    = round(current_price * 0.97, 2)
    strike_max    = round(current_price * 1.03, 2)

    try:
        contracts = client.get_option_contracts(GetOptionContractsRequest(
            underlying_symbol=symbol,
            expiration_date_gte=str(today),
            expiration_date_lte=str(exp_limit),
            type=contract_type,
            strike_price_gte=str(strike_min),
            strike_price_lte=str(strike_max),
        ))
    except Exception as e:
        logger.warning(f"  {symbol}: contract lookup failed — {e}")
        return None

    if not contracts or not contracts.option_contracts:
        logger.warning(f"  {symbol}: no {option_type} contracts found")
        return None

    liquid = [
        c for c in contracts.option_contracts
        if int(c.open_interest or 0) >= MIN_OPEN_INTEREST
    ]
    if not liquid:
        liquid = contracts.option_contracts

    return min(liquid, key=lambda c: abs(float(c.strike_price) - current_price))


def place_option_order(client, contract_symbol, qty, side, paper=True):
    try:
        order = client.submit_order(MarketOrderRequest(
            symbol=contract_symbol,
            qty=qty,
            side=OrderSide.BUY if side == "buy" else OrderSide.SELL,
            time_in_force=TimeInForce.DAY,
        ))
        logger.info(f"  Options order: {side.upper()} {qty}x {contract_symbol} id={order.id}")
        return order
    except Exception as e:
        logger.error(f"  Options order failed for {contract_symbol}: {e}")
        return None


def execute_options_trade(client, symbol, option_type, current_price,
                          max_premium, max_dte=7, paper=True):
    contract = find_best_contract(client, symbol, option_type, current_price, max_dte)
    if not contract:
        return None

    ask              = float(contract.ask_price or contract.close_price or 1.0)
    cost_per_contract = ask * 100
    if cost_per_contract <= 0:
        return None

    qty        = max(1, int(max_premium / cost_per_contract))
    total_cost = qty * cost_per_contract
    logger.info(f"  {symbol} {option_type.upper()} {contract.symbol} "
                f"strike={contract.strike_price} ask=${ask:.2f} qty={qty} total=${total_cost:.0f}")

    return place_option_order(client, contract.symbol, qty, "buy", paper)
