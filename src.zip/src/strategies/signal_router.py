"""
signal_router.py
Decides whether a gap setup should be traded via shares or options.
"""
from __future__ import annotations
from dataclasses import dataclass

MIN_GAP_PCT        = 2.0
MIN_VOL_RATIO      = 2.0
HIGH_CONV_GAP      = 5.0
HIGH_CONV_VOL      = 3.0
MAX_OPTION_PREMIUM = 1_000.0
MAX_SHARE_CAPITAL  = 20_000.0
CONVICTION_MULT    = 1.5
MAX_DTE            = 7
MIN_OPEN_INTEREST  = 100


@dataclass
class RouteDecision:
    symbol:        str
    direction:     str
    conviction:    str
    route:         str
    gap_pct:       float
    vol_ratio:     float
    trade_capital: float
    option_type:   str | None
    max_dte:       int | None
    reason:        str


def route_signal(
    symbol: str,
    gap_pct: float,
    vol_ratio: float,
    available_capital: float,
    options_enabled: bool = True,
) -> RouteDecision | None:
    direction = "long" if gap_pct > 0 else "short"
    abs_gap   = abs(gap_pct)

    if abs_gap < MIN_GAP_PCT:
        return None
    if vol_ratio < MIN_VOL_RATIO:
        return None

    conviction  = "high" if abs_gap >= HIGH_CONV_GAP and vol_ratio >= HIGH_CONV_VOL else "normal"
    option_type = None
    max_dte     = None

    if conviction == "high" and options_enabled:
        route         = "options"
        trade_capital = min(MAX_OPTION_PREMIUM, available_capital * 0.05)
        option_type   = "call" if direction == "long" else "put"
        max_dte       = MAX_DTE
        reason        = f"High conviction: gap={abs_gap:.1f}% vol={vol_ratio:.1f}x → weekly {option_type}"
    else:
        route         = "shares"
        trade_capital = min(
            MAX_SHARE_CAPITAL * (CONVICTION_MULT if conviction == "high" else 1.0),
            available_capital * 0.25,
        )
        reason = f"Normal conviction: gap={abs_gap:.1f}% vol={vol_ratio:.1f}x → shares"

    return RouteDecision(
        symbol=symbol, direction=direction, conviction=conviction,
        route=route, gap_pct=gap_pct, vol_ratio=vol_ratio,
        trade_capital=trade_capital, option_type=option_type,
        max_dte=max_dte, reason=reason,
    )
