"""Event Detection & Classification layer."""
