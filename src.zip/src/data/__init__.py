"""Data fetchers for QuantEdge."""
