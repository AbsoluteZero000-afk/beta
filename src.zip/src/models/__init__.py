"""Data models for QuantEdge."""
